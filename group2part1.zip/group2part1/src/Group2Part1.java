import java.util.HashSet;

public class Group2Part1 {
    public static void main(String[] args) {

        HashSet<Student> s = new HashSet<Student>();
        GradesDB db = new GradesDB("DB/GradesDatabase.xlsx");

        int numStud = db.getNumStudents();
        System.out.println("\nNumber of Students: " + numStud);
        s = db.getStudents();

        System.out.println("\nStudents: \n");
        for (Student temp : s) {
            System.out.println(temp.getName() + " : " + temp.getId());
        }

        Student st = db.getStudentByName("Caileigh Raybould");
        System.out.println("\nFinding student:\n" + st.getName() + " : " + st.getId() + " : " + st.getAttendance());

        int na = db.getNumAssignments();
        System.out.println("\nAssignments: " + na);

        int pa = db.getNumProjects();
        System.out.println("\nProjects: " + na);
    }


}