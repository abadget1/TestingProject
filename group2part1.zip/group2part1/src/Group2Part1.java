import java.util.HashSet;

public class Group2Part1 {
    public static void main(String[] args) {
        HashSet<Student> s = new HashSet<Student>();
        GradesDB db = new GradesDB();

        int numStud = db.getNumStudents();
        System.out.println("\n" + numStud);
        s = db.getStudents();

        System.out.println("\n");
        for (Student temp : s) {
            System.out.println(temp.getName() + " : " + temp.getID());
        }
    }
}