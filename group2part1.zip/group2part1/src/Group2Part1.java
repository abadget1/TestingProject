public class Group2Part1 {
    public static void main(String[] args) {
        GradesDB db = new GradesDB();
        db.GetData();
    }
}
