import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.io.*;
import java.util.Iterator;


public class GradesDB {
    int numAssignments;
    int numProjects;
    int numStudents;

    public void GetData() {

        try {

            FileInputStream file = new FileInputStream(new File("src/GradesDatabase.xlsx"));

            //Get the workbook instance for XLS file
            XSSFWorkbook workbook = new XSSFWorkbook(file);

            //Get first sheet from the workbook
            XSSFSheet sheet = workbook.getSheetAt(0);

            //Iterate through each rows from first sheet
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                //For each row, iterate through each columns
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();

                    switch (cell.getCellType()) {
                        case Cell.CELL_TYPE_BOOLEAN:
                            System.out.print(cell.getBooleanCellValue() + "\t\t");
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            System.out.print(cell.getNumericCellValue() + "\t\t");
                            break;
                        case Cell.CELL_TYPE_STRING:
                            System.out.print(cell.getStringCellValue() + "\t\t");
                            break;
                    }
                }
                System.out.println(" ");
            }
            file.close();
            FileOutputStream out = new FileOutputStream(new File("src/GradesDatabase.xlsx"));
            workbook.write(out);
            out.close();

        }catch (IOException e) {
            e.printStackTrace();
        }

    }


 //   HashSet<Student> studentHash;


    public int getNumStudents(){
//return number of students int
        return numOfStudents;
    }

    public int getNumAssignments(){
//return number of assignments int
        return numOfAssignments;
    }

    public int getNumProjects(){
//return number of projects int
        return numOfProjects;
    }

 /*   public HashSet<Student> getStudents(){
//return hashset of all students
        return studentHash;
    }

    public Student getStudentByName(string studentName){
//return student with matching name
    }

    public Student getStudentByID (string studentID){
//return student with matching ID
    }*/
}