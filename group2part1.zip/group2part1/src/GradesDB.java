import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.io.*;
import java.util.*;


public class GradesDB {
    int numAssignments;
    int numProjects;
    int numStudents;
    int columnNum;
    int rowNum = 0;

    List<Student> studentList = new ArrayList<Student>();

    //Constuctor - make sure getdata is called for info
    public GradesDB (){
        GetData();
    }

    public void GetData() {

        try {

            FileInputStream file = new FileInputStream(new File("src/GradesDatabase.xlsx"));

            //Get the workbook instance for XLS file
            XSSFWorkbook workbook = new XSSFWorkbook(file);

            for (int i = 0; i<workbook.getNumberOfSheets(); i++) {

                //Get first sheet from the workbook
                XSSFSheet sheet = workbook.getSheetAt(i);

                //Iterate through each rows from first sheet
                Iterator<Row> rowIterator = sheet.iterator();
                while (rowIterator.hasNext()) {
                    Row row = rowIterator.next();
                    columnNum = 1;

                    //For each row, iterate through each columns
                    Iterator<Cell> cellIterator = row.cellIterator();
                    while (cellIterator.hasNext()) {

                        Cell cell = cellIterator.next();

                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_BOOLEAN:
                                System.out.print(cell.getBooleanCellValue() + "\t\t");
                                break;
                            case Cell.CELL_TYPE_NUMERIC:
                                if (i == 0 && rowNum != 0 && columnNum == 2) {
                                    studentList.get(numStudents - 1).setID((int) cell.getNumericCellValue());
                                }
                                System.out.print(cell.getNumericCellValue() + "\t\t");
                                break;
                            case Cell.CELL_TYPE_STRING:
                                if (i == 0 && columnNum == 1 && rowNum != 0) {
                                    numStudents++;
                                    studentList.add(new Student(cell.getStringCellValue()));
                                }
                                System.out.print(cell.getStringCellValue() + "\t\t");
                                break;
                        }
                        columnNum++;
                    }
                    System.out.println(" ");
                    rowNum++;
                }
                file.close();

                FileOutputStream out = new FileOutputStream("GradesDatabase.xlsx");
                workbook.write(out);
                out.close();

                workbook = new XSSFWorkbook(new FileInputStream("GradesDatabase.xlsx"));

            }
        }catch (IOException e) {
            e.printStackTrace();
        }

    }


 //   HashSet<Student> studentHash;


    public int getNumStudents(){
//return number of students int
        return numStudents;
    }

    public int getNumAssignments(){
//return number of assignments int
        return numAssignments;
    }

    public int getNumProjects(){
//return number of projects int
        return numProjects;
    }

    public HashSet<Student> getStudents(){ //DONE
//return hashset of all students
        HashSet<Student> studentHash = new HashSet<Student>();
        for (int i = 0; i< studentList.size(); i++){
            studentHash.add(studentList.get(i));
        }

        return studentHash;
    }

    /*public Student getStudentByName(string studentName){
//return student with matching name
    }

    public Student getStudentByID (string studentID){
//return student with matching ID
    }*/
}