import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.io.*;
import java.util.*;


public class GradesDB {
    int numAssignments; //track number of assignments
    int numProjects; //track number of projects
    int numStudents; //track number of students
    int columnNum; //track current column
    int rowNum = 0; //track current row
    int studs = 0; //track students for attendance
    String f; //string for file name

    List<Student> studentList = new ArrayList<Student>();

    //Constuctor - make sure getdata is called for info
    public GradesDB (String fileName){
        f = fileName;
        GetData(fileName);
    }
    public GradesDB (){

    }

    public void loadSpreadsheet(String fileName){
        GetData(fileName);
    }

    public void GetData(String file_name) {

        try {

            FileInputStream file = new FileInputStream(new File(file_name));

            //Get the workbook instance for XLS file
            XSSFWorkbook workbook = new XSSFWorkbook(file);

            for (int i = 0; i<workbook.getNumberOfSheets(); i++) { //loop through each page

                //Get first sheet from the workbook
                XSSFSheet sheet = workbook.getSheetAt(i);

                //Iterate through each rows from first sheet
                Iterator<Row> rowIterator = sheet.iterator();
                while (rowIterator.hasNext()) {

                    Row row = rowIterator.next();
                    columnNum = 1;

                    //For each row, iterate through each columns
                    Iterator<Cell> cellIterator = row.cellIterator();
                    while (cellIterator.hasNext()) {

                        Cell cell = cellIterator.next();

                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_BOOLEAN:

                                break;
                            case Cell.CELL_TYPE_NUMERIC:
                                //if on the first page, not on the first row, and on the second column
                                if (i == 0 && rowNum != 0 && columnNum == 2) {
                                    //give each student their ID number
                                    studentList.get(numStudents - 1).setID((int) cell.getNumericCellValue());
                                }
                                //if on the third page, not on the first row, and on the second column
                                if (i == 2 && rowNum != 0 && columnNum == 2) {
                                    //give each student their attendance
                                    studentList.get(studs).setAttendance((int) cell.getNumericCellValue());
                                    studs++; //increase student tracker
                                }

                                break;
                            case Cell.CELL_TYPE_STRING:
                                //if on the first page, second column, and not on the first row
                                if (i == 0 && columnNum == 1 && rowNum != 0) {
                                    numStudents++; //increase number of students
                                    studentList.add(new Student(cell.getStringCellValue())); //add a new student to the list
                                }

                                //if on the fifth page, not on the first column, and not on the first row
                                if (i == 4 && columnNum != 1 && rowNum != 1){
                                    numProjects++; //increase number of projects
                                }

                                //if on the fourth page, not on the first column, and not on the first row
                                if (i == 3 && columnNum != 1 && rowNum != 1){
                                    numAssignments++; //increase number of assignments
                                }

                                break;
                        }
                        columnNum++; //increase column number after running through column
                    }

                    rowNum++; //increase row number after running through row
                }

                fillDB();

                file.close();

                FileOutputStream out = new FileOutputStream("GradesDatabase.xlsx");
                workbook.write(out);
                out.close();

                workbook = new XSSFWorkbook(new FileInputStream("GradesDatabase.xlsx"));

            }

        }

        catch (IOException e) {
            e.printStackTrace();
        }

    }


    public int getNumStudents(){
    //return number of students int
        return numStudents;
    }

    public int getNumAssignments(){
    //return number of assignments int
        return numAssignments;
    }

    public int getNumProjects(){
    //return number of projects int
        return numProjects;
    }

    public HashSet<Student> getStudents(){

    //return hashset of all students
        HashSet<Student> studentHash = new HashSet<Student>();
        for (int i = 0; i< studentList.size(); i++){
            studentHash.add(studentList.get(i));
        }
        return studentHash;
    }

    public Student getStudentByName(String studentName){

    //return student with matching name
        Student s = null;
        for (Student temp : studentList) {
            if (temp.getName().equals(studentName)){
                return temp;
            }
        }
        return s;
    }

    public Student getStudentByID (String studentID){

    //return student with matching ID
        Student s = null;
        for (Student stu : studentList)
        {
            if (stu.getId().equals(studentID)) {
                return stu;
            }
        }
        return s;
    }

    private void fillDB (){
        for (Student s : studentList){
            s.stuDB = this;
        }
    }

    public int getAssignmentAverage(Student s){

    }

    public int getProjectAverage(Student s){

    }

    public void addAssignment(String assignmentName){

    }

    public void addAssignmentGrade(Student s, int grade, String assignmentName){

    }

    public void addIndividualGrade(Student s, int grade, String assignmentName){

    }


}