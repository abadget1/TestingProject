import java.util.HashSet;
import java.io.File;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.Assert.assertTrue;

public class Group2Part1 {
    public static void main(String[] args) {

        GradesDB db = null;
        HashSet<Student> s = new HashSet<Student>();
        GradesDB db1 = new GradesDB("DB/GradesDatabase.xlsx");
        final String GRADES_DB = "DB" + File.separator
                + "GradesDatabase.xlsx";
        db = new GradesDB();
        db.loadSpreadsheet(GRADES_DB);

        int numStud = db.getNumStudents();
        System.out.println("\nNumber of Students: " + numStud);
        s = db.getStudents();

        System.out.println("\nStudents: \n");
        for (Student temp : s) {
            System.out.println(temp.getName() + " : " + temp.getId() + " : " + temp.getAttendance() + " : " + temp.stuDB);
        }

        Student st = db.getStudentByName("Caileigh Raybould");
        System.out.println("\nFinding student:\n" + st.getName() + " : " + st.getId() + " : " + st.getAttendance()+ " : " + st.stuDB);

        int na = db.getNumAssignments();
        System.out.println("\nAssignments: " + na);

        int pa = db.getNumProjects();
        System.out.println("\nProjects: " + na);

        Student stu = new Student("Cynthia Faast", "1234514", db);
        HashSet<Student> students = null;
        students = db.getStudents();

        System.out.println("\nStudents in students: \n");
        for (Student t : students) {
            System.out.println(t.getName() + " : " + t.getId() + " : " + t.getAttendance() + " : " + t.stuDB);
        }

        if (students.contains(stu)){
            System.out.println("does contain");
        }
        else
            System.out.println("does not contain");

    }


}